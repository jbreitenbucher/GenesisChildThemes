<?php
/** Start the engine */
require_once( get_template_directory() . '/lib/init.php' );

/** Child theme (do not remove) */
define( 'CHILD_THEME_NAME', 'Sample Child Theme' );
define( 'CHILD_THEME_URL', 'http://www.studiopress.com/themes/genesis' );

/** Add Viewport meta tag for mobile browsers */
add_action( 'genesis_meta', 'add_viewport_meta_tag' );
function add_viewport_meta_tag() {
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
}

/** Add support for 3-column footer widgets */
add_theme_support( 'genesis-footer-widgets', 3 );

// Customize Post Content
remove_action('genesis_before_post_content', 'genesis_post_info');
remove_action('genesis_post_title', 'genesis_do_post_title');
remove_action('genesis_after_post_title', 'genesis_do_after_post_title');
remove_action('genesis_after_post_content', 'genesis_post_meta');
remove_action('genesis_post_content','genesis_do_post_content');
add_action('genesis_post_content','df_post_content');
remove_action('genesis_post_content', 'genesis_do_post_image');
remove_action('genesis_after_endwhile','genesis_do_after_endwhile');
remove_action('genesis_after_endwhile', 'genesis_posts_nav');

/** Customize the credits */
add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
function custom_footer_creds_text($creds) {
    $creds = '&copy; ' . date("Y") . '. All Rights Reserved. Dorman Farrell, LLC | <a href="about/licenses/">Licenses</a>';
    return $creds;
}

/**
 * Customize Post Content
 *
 * @author Jon Breitenbucher
 */

function df_post_content() {
	if ( is_home() ) {
		if ( is_active_sidebar( 'featured' ) ) {
			echo '<div class="featured">';
				dynamic_sidebar( 'featured' );
			echo '</div><!-- end .featured -->';
		}
	}
	elseif ( genesis_do_post_image() != '' ) {
		echo '<div class="post-image">'. genesis_do_post_image() . '</div>';
		echo '<div class="post-inner-image">';
			genesis_do_post_title();
			echo '<div class="post-content">';
				the_content();
			echo '</div>';
		echo '</div>';
	} else {
	echo '<div class="post-inner">';
		genesis_do_post_title();
		echo '<div class="post-content">';
			the_content();
		echo '</div>';
	echo '</div>';
	}
}

/** Unregister layout setting */
genesis_unregister_layout( 'content-sidebar' );
genesis_unregister_layout( 'sidebar-content' );
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

genesis_register_sidebar( array(
	'id'			=> 'featured',
	'name'			=> __( 'Featured' ),
	'description'	=> __( 'This is the featured section on the homepage.' ),
) );
